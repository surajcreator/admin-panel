﻿
Partial Class admin_products
    Inherits System.Web.UI.Page

End Class
