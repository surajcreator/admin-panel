﻿
Partial Class admin_adminMaster
    Inherits System.Web.UI.MasterPage
End Class

